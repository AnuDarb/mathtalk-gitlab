from flask import Flask, request, jsonify, render_template
from database import init_db, add_question, create_connection
import sqlite3

app = Flask(__name__)

@app.route("/")
def home():
    return render_template("index.html")

@app.route("/api/save", methods=["POST"])
def save_user_answer():
    data = request.get_json()
    user_input = data.get("user_input")
    question_id = data.get("question_id")

    if not user_input or not question_id:
        return jsonify({"success": False, "error": "Fehlende Daten"}), 400

    conn = create_connection()
    cursor = conn.cursor()
    try:
        cursor.execute("INSERT INTO user_answers (question_id, user_input) VALUES (?, ?)", (question_id, user_input))
        conn.commit()
        return jsonify({"success": True})
    except Exception as e:
        return jsonify({"success": False, "error": str(e)}), 500
    finally:
        conn.close()

@app.route("/api/question/<int:question_id>", methods=["GET"])
def get_question(question_id):
    conn = create_connection()
    cursor = conn.cursor()
    cursor.execute("SELECT question, answer, question_type FROM questions WHERE id = ?", (question_id,))
    row = cursor.fetchone()
    conn.close()
    if row:
        return jsonify({
            "question": row[0],
            "answer": row[1],
            "type": row[2]
        })
    else:
        return jsonify({"error": "Frage nicht gefunden"}), 404

if __name__ == "__main__":
    init_db()
    app.run(debug=True)