let questionId = 1;

function toggleOptions() {
  const panel = document.getElementById('optionsPanel');
  panel.classList.toggle('visible');
}

function saveOptions() {
  alert("Optionen gespeichert!");
}

// Eine Frage aus der Datenbank laden
async function loadQuestion(id) {
  const response = await fetch(`/api/question/${id}`);
  const data = await response.json();
  const questionText = document.getElementById("questionText");

  if (data.question) {
    questionText.innerText = data.question;
    document.getElementById("answerInput").value = "";
  } else {
    questionText.innerText = "🎉 Alle Aufgaben abgeschlossen!";
    const button = document.querySelector(".buton-weiter button");
    button.disabled = true;
    button.innerText = "Fertig!";
  }
}

// Antwort absenden, Score prüfen, nächste Frage laden
async function submitAnswer() {
  const button = document.querySelector(".buton-weiter button");
  const answer = document.getElementById("answerInput").value;

  // UI: deaktivieren + Feedback
  button.disabled = true;
  button.style.backgroundColor = "#888";
  button.innerText = "Wird gesendet...";

  // Anfrage senden
  const response = await fetch("/api/save", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ user_input: answer, question_id: questionId })
  });

  const result = await response.json();

  if (result.success) {
    const score = result.score;
    // Bewertung anzeigen
    if (score > 0.85) {
      alert("✅ Richtig!");
    } else if (score > 0.65) {
      alert("🔁 Fast richtig – überprüfe deine Schreibweise.");
    } else {
      alert("❌ Leider falsch.");
    }

    questionId++; // nächste Frage
    setTimeout(() => {
      loadQuestion(questionId);
      button.disabled = false;
      button.innerText = "Weiter";
      button.style.backgroundColor = "#007bff";
    }, 1000);

  } else {
    button.innerText = "Fehler";
    setTimeout(() => {
      button.disabled = false;
      button.innerText = "Weiter";
      button.style.backgroundColor = "#007bff";
    }, 1500);
  }
}

// Beim Laden starten mit erster Frage
loadQuestion(questionId);